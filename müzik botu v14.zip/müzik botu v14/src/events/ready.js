const { Events, ActivityType, REST, Routes } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`[BOT] Ready! Logged in as ${client.user.tag}`);
        client.lavalink.init(client.user);

        // --- 🚀 OTOMATİK KOMUT MÜHÜRLEME (Elit Auto-Deploy) ---
        try {
            console.log(' [SYSTEM] Komutlar otomatik olarak taranıyor ve mühürleniyor...');
            const commands = client.commands.map(cmd => cmd.data.toJSON());
            const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

            await rest.put(
                Routes.applicationCommands(process.env.CLIENT_ID),
                { body: commands },
            );
            console.log(' [SUCCESS] Tüm komutlar başarıyla mühürlendi. (Auto-Deploy Complete)');
        } catch (error) {
            console.error(' [CRITICAL ERROR] Otomatik mühürleme başarısız:', error);
        }

        // --- 🎮 DİNAMİK TWITCH PRESENCE (Masterpiece V12) ---
        try {
            const statusText = process.env.STATUS_TEXT || 'Elit Prestige V12';
            const streamUrl = process.env.STREAM_URL || 'https://www.twitch.tv/elit';

            client.user.setActivity(statusText, {
                type: ActivityType.Streaming,
                url: streamUrl
            });
            console.log(` [SYSTEM] Presence Aktif: ${statusText} (Streaming Mode)`);
        } catch (e) {
            console.error(' [SYSTEM ERROR] Presence atanırken bir hata saptandı:', e);
        }
    },
};

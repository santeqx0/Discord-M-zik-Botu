const { Events, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const { generateMusicCard, createControlButtons } = require('../utils/canvasBuilder');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        // --- 💎 ULTRA-RESILIENT INTERACTION SHIELD (Akıllı Kalkan) ---
        // Bu sistem, Discord'un gecikmeli veya başarısız ACK durumlarını otomatik yönetir.
        const smartReply = async (options) => {
            try {
                if (interaction.replied) return await interaction.followUp(options).catch(() => { });
                if (interaction.deferred) return await interaction.editReply(options).catch(() => { });
                return await interaction.reply(options).catch(() => { });
            } catch (e) { }
        };

        const smartUpdate = async (options) => {
            try {
                if (interaction.deferred || interaction.replied) {
                    return await interaction.editReply(options).catch(() => { });
                }
                return await interaction.update(options).catch(() => { });
            } catch (e) { }
        };

        // --- 1. KOMUT İŞLEME ---
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;

            // Her komut için güvenli DEFER denemesi (Ephermal değil, herkes görsün)
            try {
                if (!interaction.deferred && !interaction.replied) {
                    await interaction.deferReply().catch(() => { });
                }
            } catch (e) { }

            try {
                // Komutu zırhlı yanıt metoduyla besleyerek çalıştır
                interaction.smartReply = smartReply;
                await command.execute(interaction, client);
            } catch (error) {
                console.error(" [CRITICAL COMMAND ERROR]:", error);
                await smartReply({ content: '❓ **Sistem Hatası:** İşlem gerçekleştirilemedi.', flags: 64 });
            }
        }

        // --- 2. BUTON İŞLEME ---
        else if (interaction.isButton()) {
            const player = client.lavalink.getPlayer(interaction.guild.id);
            if (!player) return await smartReply({ content: '⚠️ **Geçersiz Oturum:** Lütfen yeni bir şarkı başlatın.', flags: 64 });

            if (interaction.member.voice.channelId !== player.voiceChannelId) {
                return await smartReply({ content: '❌ **Farklı Kanal:** Botla aynı ses kanalında olmalısın!', flags: 64 });
            }

            // Modal Senaryosu (Update/Defer YAPILMAZ)
            if (interaction.customId === 'music_modal_volume' || interaction.customId === 'music_modal_search') {
                const modal = new ModalBuilder();
                if (interaction.customId === 'music_modal_volume') {
                    modal.setCustomId('modal_volume_input').setTitle('🎚️ Ses Ayarı');
                    modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('volume_value').setLabel("Ses Seviyesi (0-100)").setPlaceholder(`${player.volume}`).setStyle(TextInputStyle.Short).setRequired(true)));
                } else {
                    modal.setCustomId('modal_search_input').setTitle('🔍 Şarkı Ekle');
                    modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('search_query').setLabel("Şarkı Adı/Link").setPlaceholder("spotify:track:...").setStyle(TextInputStyle.Short).setRequired(true)));
                }
                return await interaction.showModal(modal).catch(() => { });
            }

            // Butonlar için anında Defer
            if (!interaction.deferred && !interaction.replied) {
                await interaction.deferUpdate().catch(() => { });
            }

            const { isDJ } = require('../utils/djCheck');
            const protectedButtons = ['music_resume_pause', 'music_skip', 'music_vol_up', 'music_vol_down', 'music_stop', 'music_shuffle', 'music_loop', 'music_clear', 'music_previous'];
            
            if (protectedButtons.includes(interaction.customId)) {
                if (!isDJ(interaction, player)) {
                    return await smartReply({ content: '❌ **Yetki Yok:** Bu düğmeyi kullanmak için DJ yetkisine veya şarkıyı isteyen kişi olmana ihtiyacın var!', flags: 64 });
                }
            }

            try {
                let needsUpdate = false;
                switch (interaction.customId) {
                    case 'music_resume_pause':
                        player.paused ? await player.resume() : await player.pause();
                        needsUpdate = true;
                        break;
                    case 'music_skip':
                        await player.skip();
                        break;
                    case 'music_vol_up':
                        await player.setVolume(Math.min(100, player.volume + 10));
                        needsUpdate = true;
                        break;
                    case 'music_vol_down':
                        await player.setVolume(Math.max(0, player.volume - 10));
                        needsUpdate = true;
                        break;
                    case 'music_stop':
                        await smartUpdate({ content: '🛑 **Müzik durduruldu ve oturum kapatıldı.**', components: [], files: [] });
                        return setTimeout(() => { if (player) player.destroy(); }, 1000);
                    case 'music_queue':
                        const q = player.queue.tracks.map((t, i) => `${i + 1}. ${t.info.title}`).slice(0, 5).join('\n');
                        return await smartReply({ content: `📜 **Sıra:**\n${q || 'Sıra boş.'}`, flags: 64 });
                    case 'music_shuffle':
                        await player.queue.shuffle();
                        needsUpdate = true;
                        await smartReply({ content: '🔀 **Sıra karıştırıldı.**', flags: 64 });
                        break;
                    case 'music_loop':
                        const modes = ['off', 'track', 'queue'];
                        await player.setRepeatMode(modes[(modes.indexOf(player.repeatMode || 'off') + 1) % modes.length]);
                        needsUpdate = true;
                        break;
                    case 'music_clear':
                        await player.queue.clear();
                        needsUpdate = true;
                        await smartReply({ content: '🗑️ **Sıra temizlendi.**', flags: 64 });
                        break;
                    case 'music_previous':
                        if (player.queue.previous.length) await player.play({ track: player.queue.previous[player.queue.previous.length - 1] });
                        else await smartReply({ content: '⏮️ **Eski şarkı yok.**', flags: 64 });
                        break;
                }

                if (needsUpdate && player.playing && !player.paused) {
                    const attachment = await generateMusicCard(player);
                    await smartUpdate({ files: [attachment], components: createControlButtons(player) });
                } else if (needsUpdate) {
                    // Sadece butonları güncelle (Canvas oluşturma - CPU Tasarrufu)
                    await smartUpdate({ components: createControlButtons(player) });
                }
            } catch (err) { }
        }

        // --- 3. MODAL SUBMIT ---
        else if (interaction.isModalSubmit()) {
            const player = client.lavalink.getPlayer(interaction.guild.id);
            if (!player) return await smartReply({ content: '⚠️ Oynatıcı kapalı.', flags: 64 });

            try {
                if (interaction.customId === 'modal_volume_input') {
                    const vol = parseInt(interaction.fields.getTextInputValue('volume_value'));
                    if (isNaN(vol) || vol < 0 || vol > 100) return await smartReply({ content: '❌ Geçersiz ses!', flags: 64 });
                    await player.setVolume(vol);
                    await smartReply({ content: `🔊 Ses **%${vol}** yapıldı.`, flags: 64 });
                    if (player.playing && !player.paused) {
                        const attachment = await generateMusicCard(player);
                        await interaction.message.edit({ files: [attachment], components: createControlButtons(player) }).catch(() => { });
                    } else if (player.playing) {
                        await interaction.message.edit({ components: createControlButtons(player) }).catch(() => { });
                    }
                } else if (interaction.customId === 'modal_search_input') {
                    if (!interaction.deferred && !interaction.replied) await interaction.deferReply({ flags: 64 }).catch(() => { });
                    const query = interaction.fields.getTextInputValue('search_query');
                    const res = await player.search({ query, source: "scsearch" }, interaction.user).catch(() => null);
                    if (!res || !res.tracks.length) return await smartUpdate({ content: '❌ Sonuç yok.' });
                    await player.queue.add(res.tracks[0]);
                    if (!player.playing && !player.paused) await player.play();
                    await smartUpdate({ content: `✅ **${res.tracks[0].info.title}** eklendi.` });
                }
            } catch (e) { }
        }
    }
};

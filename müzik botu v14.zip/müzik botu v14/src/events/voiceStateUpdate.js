const { Events } = require('discord.js');
const db = require('../database/db');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState, client) {
        const guildId = oldState.guild.id;
        const player = client.lavalink.getPlayer(guildId);
        if (!player) return;

        // Botun bulunduğu kanalın güncel hali
        const voiceChannel = oldState.guild.channels.cache.get(player.voiceChannelId);
        if (!voiceChannel) return;

        // Eğer kanalda sadece bot kaldıysa ve 24/7 modu kapalıysa
        const guildData = db.getGuild(guildId);
        if (voiceChannel.members.filter(m => !m.user.bot).size === 0 && !guildData.stay247) {
            // 2 dakika sonra hala kimse gelmemişse çık
            setTimeout(async () => {
                const updatedChannel = oldState.guild.channels.cache.get(player.voiceChannelId);
                if (updatedChannel && updatedChannel.members.filter(m => !m.user.bot).size === 0) {
                    if (player) {
                        player.destroy();
                        const textChannel = client.channels.cache.get(player.textChannelId);
                        if (textChannel) {
                            await textChannel.send({ content: '👋 **Kanalda kimse kalmadığı için ayrıldım.** (Elit Prestige)' }).catch(() => { });
                        }
                    }
                }
            }, 120000);
        }
    }
};

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('filters')
        .setDescription('Ses filtrelerini yönetir.')
        .addStringOption(option =>
            option.setName('tip')
                .setDescription('Uygulanacak filtre')
                .setRequired(true)
                .addChoices(
                    { name: '❌ Filtreleri Temizle', value: 'clear' },
                    { name: '🔊 Bassboost', value: 'bassboost' },
                    { name: '🏃 Nightcore', value: 'nightcore' },
                    { name: '🎧 8D (Çevresel)', value: '8d' },
                    { name: '🌊 Vaporwave', value: 'vaporwave' }
                )),
    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);
        if (!player) return await interaction.smartReply({ content: '⚠️ Şu an bir şarkı çalmıyor.' });

        if (interaction.member.voice.channelId !== player.voiceChannelId) {
            return await interaction.smartReply({ content: '❌ Bot ile aynı ses kanalında olmalısın!' });
        }

        const { isDJ } = require('../utils/djCheck');
        if (!isDJ(interaction, player)) {
            return await interaction.smartReply({ content: '❌ Bu işlemi yapmak için DJ yetkisine veya şarkıyı isteyen kişi olmana ihtiyacın var!', flags: 64 });
        }

        const filter = interaction.options.getString('tip');

        try {
            switch (filter) {
                case 'clear':
                    await player.filterManager.clearFilters();
                    break;
                case 'bassboost':
                    await player.filterManager.setFilters({
                        equalizer: [
                            { band: 0, gain: 0.6 }, { band: 1, gain: 0.5 }, { band: 2, gain: 0.4 }
                        ]
                    });
                    break;
                case 'nightcore':
                    await player.filterManager.setFilters({
                        timescale: { speed: 1.2, pitch: 1.2 }
                    });
                    break;
                case '8d':
                    await player.filterManager.setFilters({
                        rotation: { rotationHz: 0.2 }
                    });
                    break;
                case 'vaporwave':
                    await player.filterManager.setFilters({
                        timescale: { speed: 0.8, pitch: 0.8 }
                    });
                    break;
            }

            return await interaction.smartReply({ content: `✅ Filtre güncellendi: **${filter.toUpperCase()}**` });
        } catch (e) {
            return await interaction.smartReply({ content: '❌ Filtre uygulanırken bir hata oluştu.' });
        }
    },
};

const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('resume')
        .setDescription('Duraklatılmış müziği devam ettirir'),

    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);

        if (!player || !player.queue.current) {
            return interaction.smartReply({ content: '⚠️ Şu an bir şarkı çalmıyor.', flags: 64 });
        }
        if (interaction.member.voice.channelId !== player.voiceChannelId) {
            return interaction.smartReply({ content: '❌ Bot ile aynı ses kanalında olmalısın!', flags: 64 });
        }
        if (!player.paused) {
            return interaction.smartReply({ content: '▶️ Müzik zaten çalıyor.', flags: 64 });
        }

        await player.resume();
        return interaction.smartReply({ content: '▶️ Müzik devam ediyor.' });
    },
};

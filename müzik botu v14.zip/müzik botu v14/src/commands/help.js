const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Tüm komutları ve kullanım rehberini gösterir'),

    async execute(interaction, client) {
        const embed = new EmbedBuilder()
            .setColor('#5865F2')
            .setAuthor({
                name: `${client.user.username} — Komut Rehberi`,
                iconURL: client.user.displayAvatarURL({ size: 256 })
            })
            .setDescription(
                '> Tüm komutlar `/` ile kullanılır. Müzik komutları için ses kanalında olman gerekir.\n\u200b'
            )
            .addFields(
                {
                    name: '🎵 Müzik',
                    value: [
                        '`/play [şarkı]` — Şarkı veya link çalar',
                        '`/pause` — Müziği duraklatır',
                        '`/resume` — Devam ettirir',
                        '`/skip` — Şarkıyı atlar',
                        '`/stop` — Müziği durdurur ve çıkar',
                        '`/seek [süre]` — Şarkıyı ileri/geri sarar (ör: `1:30`)',
                        '`/volume [0-100]` — Ses seviyesini ayarlar',
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '📋 Sıra & Bilgi',
                    value: [
                        '`/queue` — Çalma sırasını gösterir',
                        '`/nowplaying` — Şu an çalanı gösterir',
                        '`/playlist` — Playlist yönetimi',
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '🎛️ Efektler',
                    value: [
                        '`/filters [tip]` — Ses efektleri',
                        '*Bassboost, Nightcore, 8D, Vaporwave, Normal*',
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '✨ Ekstra',
                    value: [
                        '`/lyrics [şarkı]` — Şarkı sözlerini getirir',
                        '`/stats` — Bot sistem istatistikleri',
                        '`/setup` — DJ & kanal ayarları',
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '🔊 AutoPlay',
                    value: 'Sıra bittiğinde son şarkıya benzer parçalar otomatik eklenir.',
                    inline: false
                }
            )
            .setFooter({
                text: `${client.guilds.cache.size} sunucuda hizmet veriyorum • Elit Music`,
                iconURL: client.user.displayAvatarURL()
            })
            .setTimestamp();

        return interaction.smartReply({ embeds: [embed], flags: 64 });
    },
};

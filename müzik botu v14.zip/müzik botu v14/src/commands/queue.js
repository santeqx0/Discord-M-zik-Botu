const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const formatDuration = (ms) => {
    if (!ms || ms <= 0) return '∞';
    const s = Math.floor((ms / 1000) % 60);
    const m = Math.floor((ms / 60000) % 60);
    const h = Math.floor(ms / 3600000);
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${m}:${String(s).padStart(2, '0')}`;
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('queue')
        .setDescription('Çalma sırasını gösterir')
        .addIntegerOption(opt =>
            opt.setName('sayfa')
                .setDescription('Sayfa numarası')
                .setMinValue(1)
                .setRequired(false)
        ),

    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);
        if (!player || !player.queue.current) {
            return interaction.smartReply({ content: '⚠️ Şu an aktif bir çalma sırası yok.', flags: 64 });
        }

        const PAGE_SIZE = 10;
        const page = (interaction.options.getInteger('sayfa') || 1) - 1;
        const tracks = player.queue.tracks;
        const totalPages = Math.max(1, Math.ceil(tracks.length / PAGE_SIZE));
        const safePage = Math.min(page, totalPages - 1);

        const current = player.queue.current;
        const loopEmoji = player.repeatMode === 'track' ? '🔂' : player.repeatMode === 'queue' ? '🔁' : '➡️';

        const queueLines = tracks
            .slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE)
            .map((t, i) => {
                const idx = safePage * PAGE_SIZE + i + 1;
                const dur = formatDuration(t.info.length);
                const requester = t.requester ? `<@${t.requester.id}>` : 'Bilinmiyor';
                return `\`${String(idx).padStart(2, ' ')}.\` **${t.info.title.slice(0, 45)}${t.info.title.length > 45 ? '…' : ''}** — \`${dur}\`\n     └ ${requester}`;
            })
            .join('\n');

        const totalDuration = tracks.reduce((acc, t) => acc + (t.info.length || 0), 0);

        const embed = new EmbedBuilder()
            .setColor('#5865F2')
            .setTitle('📜 Çalma Sırası')
            .setDescription(
                `**▶ Şu an çalıyor:** [${current.info.title}](${current.info.uri})\n` +
                `**Döngü:** ${loopEmoji}  **Ses:** 🔊 %${player.volume}\n\n` +
                (queueLines || '_Sıra boş._')
            )
            .addFields({
                name: '📊 Genel',
                value: `**${tracks.length}** şarkı • Toplam süre: **${formatDuration(totalDuration)}**`,
                inline: false
            })
            .setFooter({ text: `Sayfa ${safePage + 1} / ${totalPages} • Sunucu: ${interaction.guild.name}` })
            .setTimestamp();

        return interaction.smartReply({ embeds: [embed], flags: 64 });
    },
};

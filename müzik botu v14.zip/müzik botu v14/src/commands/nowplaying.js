const { SlashCommandBuilder } = require('discord.js');
const { generateMusicCard, createControlButtons } = require('../utils/canvasBuilder');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nowplaying')
        .setDescription('O an çalan şarkının detaylı kartını gösterir.'),
    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);
        if (!player || !player.queue.current) return await interaction.smartReply({ content: '⚠️ Şu an bir şarkı çalmıyor.' });

        const attachment = await generateMusicCard(player);
        const components = createControlButtons(player);

        return await interaction.smartReply({
            files: [attachment],
            components: components
        });
    },
};

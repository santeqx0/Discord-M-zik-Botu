const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('volume')
        .setDescription('Ses seviyesini görüntüler veya ayarlar')
        .addIntegerOption(opt =>
            opt.setName('seviye')
                .setDescription('Yeni ses seviyesi (0-100)')
                .setMinValue(0)
                .setMaxValue(100)
                .setRequired(false)
        ),

    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);

        if (!player) {
            return interaction.smartReply({ content: '⚠️ Şu an bir şarkı çalmıyor.', flags: 64 });
        }
        if (interaction.member.voice.channelId !== player.voiceChannelId) {
            return interaction.smartReply({ content: '❌ Bot ile aynı ses kanalında olmalısın!', flags: 64 });
        }

        const seviye = interaction.options.getInteger('seviye');

        // Seviye verilmemişse mevcut sesi göster
        if (seviye === null) {
            const bar = buildVolumeBar(player.volume);
            return interaction.smartReply({
                content: `🔊 **Mevcut Ses:** %${player.volume}\n${bar}`,
                flags: 64
            });
        }

        const { isDJ } = require('../utils/djCheck');
        if (!isDJ(interaction, player)) {
            return interaction.smartReply({ content: '❌ DJ yetkisi veya şarkıyı isteyen kişi olman gerekiyor!', flags: 64 });
        }

        await player.setVolume(seviye);
        const bar = buildVolumeBar(seviye);
        const emoji = seviye === 0 ? '🔇' : seviye < 30 ? '🔈' : seviye < 70 ? '🔉' : '🔊';

        return interaction.smartReply({
            content: `${emoji} **Ses seviyesi %${seviye} olarak ayarlandı.**\n${bar}`
        });
    },
};

function buildVolumeBar(vol) {
    const filled = Math.round(vol / 10);
    const empty = 10 - filled;
    return `${'▰'.repeat(filled)}${'▱'.repeat(empty)} **%${vol}**`;
}

const { SlashCommandBuilder } = require('discord.js');

// Arama kaynağı öncelik sırası
const SEARCH_SOURCES = ['scsearch', 'ytmsearch', 'ytsearch'];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('Şarkı veya playlist çalar')
        .addStringOption(option =>
            option.setName('sarki')
                .setDescription('Şarkı adı, YouTube/Spotify/SoundCloud linki')
                .setRequired(true)
                .setAutocomplete(false)),

    async execute(interaction, client) {
        const query = interaction.options.getString('sarki')?.trim();
        const voiceChannel = interaction.member?.voice?.channel;

        if (!query) {
            return interaction.smartReply({ content: '❌ Lütfen bir şarkı adı veya link gir!', flags: 64 });
        }

        if (!voiceChannel) {
            return interaction.smartReply({ content: '❌ Önce bir ses kanalına gir!', flags: 64 });
        }

        // Bot'un o kanala bağlanma yetkisi var mı?
        const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
        if (!permissions.has('Connect') || !permissions.has('Speak')) {
            return interaction.smartReply({ content: '❌ Bu ses kanalına bağlanma veya konuşma yetkim yok!', flags: 64 });
        }

        let player;
        try {
            player = client.lavalink.createPlayer({
                guildId: interaction.guild.id,
                voiceChannelId: voiceChannel.id,
                textChannelId: interaction.channel.id,
                selfDeaf: true,
                selfMute: false,
                volume: 80
            });

            await player.connect();
        } catch (e) {
            console.error('[Play] Player oluşturma/bağlanma hatası:', e?.message);
            return interaction.smartReply({ content: '❌ Ses kanalına bağlanırken hata oluştu. Lütfen tekrar dene!', flags: 64 });
        }

        try {
            const isUrl = /^https?:\/\//i.test(query);
            let res = null;
            let usedSource = '';

            if (isUrl) {
                // Link ise direkt ara
                res = await player.search({ query }, interaction.user).catch(() => null);
                usedSource = 'link';
            } else {
                // Metin ise sırayla kaynaklarda dene
                for (const source of SEARCH_SOURCES) {
                    res = await player.search({ query, source }, interaction.user).catch(() => null);
                    if (res?.tracks?.length) {
                        usedSource = source;
                        break;
                    }
                }
            }

            if (!res || !res.tracks?.length) {
                // Player'ı temizle eğer hiç şarkı çalmıyorsa
                if (!player.playing && !player.paused && player.queue.tracks.length === 0) {
                    player.destroy().catch(() => {});
                }
                return interaction.smartReply({ content: `🔍 **"${query}"** için sonuç bulunamadı. Farklı bir arama dene!`, flags: 64 });
            }

            // Requester bilgisini sakla (AutoPlay için)
            const requesterInfo = interaction.user;

            if (res.loadType === 'playlist') {
                // Playlist'teki her şarkıya requester ekle
                res.tracks.forEach(t => t.requester = requesterInfo);
                await player.queue.add(res.tracks);
                if (!player.playing && !player.paused) await player.play();

                return interaction.smartReply({
                    content: `🎶 **Playlist eklendi:** **${res.playlist?.title || 'Bilinmeyen Playlist'}**\n📋 **${res.tracks.length} şarkı** sıraya eklendi.`
                });
            } else {
                const track = res.tracks[0];
                track.requester = requesterInfo;

                const position = player.queue.tracks.length;
                await player.queue.add(track);

                if (!player.playing && !player.paused) {
                    await player.play();
                    return interaction.smartReply({
                        content: `▶️ **Çalınıyor:** **${track.info.title}** — *${track.info.author}*`
                    });
                } else {
                    return interaction.smartReply({
                        content: `✅ **Sıraya eklendi [#${position + 1}]:** **${track.info.title}** — *${track.info.author}*`
                    });
                }
            }

        } catch (e) {
            console.error('[Play] Arama/oynatma hatası:', e?.message);
            // Player boşsa temizle
            try {
                if (player && !player.playing && player.queue.tracks.length === 0) {
                    await player.destroy();
                }
            } catch (_) {}
            return interaction.smartReply({ content: '❌ Şarkı aranırken bir hata oluştu. Lütfen tekrar dene!', flags: 64 });
        }
    },
};

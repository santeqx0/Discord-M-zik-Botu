const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('pause')
        .setDescription('Müziği duraklatır veya devam ettirir (toggle)'),

    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);

        if (!player || !player.queue.current) {
            return interaction.smartReply({ content: '⚠️ Şu an bir şarkı çalmıyor.', flags: 64 });
        }
        if (interaction.member.voice.channelId !== player.voiceChannelId) {
            return interaction.smartReply({ content: '❌ Bot ile aynı ses kanalında olmalısın!', flags: 64 });
        }

        const { isDJ } = require('../utils/djCheck');
        if (!isDJ(interaction, player)) {
            return interaction.smartReply({ content: '❌ DJ yetkisi veya şarkıyı isteyen kişi olman gerekiyor!', flags: 64 });
        }

        if (player.paused) {
            await player.resume();
            return interaction.smartReply({ content: '▶️ Müzik devam ediyor.' });
        } else {
            await player.pause();
            return interaction.smartReply({ content: '⏸️ Müzik duraklatıldı.' });
        }
    },
};

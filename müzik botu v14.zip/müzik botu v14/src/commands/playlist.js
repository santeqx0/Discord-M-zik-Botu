const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../database/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('playlist')
        .setDescription('Kişisel çalma listelerinizi yönetir.')
        .addSubcommand(sub =>
            sub.setName('save')
                .setDescription('Şu anki sırayı bir liste olarak kaydeder.')
                .addStringOption(opt => opt.setName('isim').setDescription('Liste ismi').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('load')
                .setDescription('Kaydedilmiş bir listeyi yükler.')
                .addStringOption(opt => opt.setName('isim').setDescription('Liste ismi').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('list')
                .setDescription('Tüm listelerinizi gösterir.')
        )
        .addSubcommand(sub =>
            sub.setName('delete')
                .setDescription('Bir listeyi siler.')
                .addStringOption(opt => opt.setName('isim').setDescription('Liste ismi').setRequired(true))
        ),
    async execute(interaction, client) {
        const subcommand = interaction.options.getSubcommand();
        const userId = interaction.user.id;
        const name = interaction.options.getString('isim');

        if (subcommand === 'save') {
            const player = client.lavalink.getPlayer(interaction.guild.id);
            if (!player || !player.queue.current) return await interaction.smartReply({ content: '❌ Şu an çalan bir şey yok.', flags: 64 });

            const tracks = [player.queue.current.info.uri, ...player.queue.tracks.map(t => t.info.uri)];
            db.saveUserPlaylist(userId, name, tracks);

            return await interaction.smartReply({ content: `✅ **${name}** isimli listeniz ${tracks.length} şarkı ile kaydedildi!` });
        }

        if (subcommand === 'load') {
            const tracks = db.getUserPlaylist(userId, name);
            if (!tracks) return await interaction.smartReply({ content: '❌ Böyle bir liste bulunamadı.', flags: 64 });

            const player = client.lavalink.getPlayer(interaction.guild.id) || await client.lavalink.createPlayer({
                guildId: interaction.guild.id,
                voiceChannelId: interaction.member.voice.channelId,
                textChannelId: interaction.channelId,
                selfDeaf: true
            });

            if (!player.connected) await player.connect();

            await interaction.smartReply({ content: `⏳ **${name}** yükleniyor (${tracks.length} şarkı)...` });

            for (const uri of tracks) {
                const res = await player.search({ query: uri }, interaction.user);
                if (res.tracks.length) await player.queue.add(res.tracks[0]);
            }

            if (!player.playing) await player.play();
            return await interaction.editReply({ content: `✅ **${name}** başarıyla yüklendi ve çalmaya başladı!` });
        }

        if (subcommand === 'list') {
            const user = db.data.users?.[userId];
            if (!user || Object.keys(user.playlists).length === 0) return await interaction.smartReply({ content: '❌ Kayıtlı listeniz bulunmuyor.', flags: 64 });

            const list = Object.keys(user.playlists).map((n, i) => `${i + 1}. **${n}** (${user.playlists[n].length} Şarkı)`).join('\n');
            const embed = new EmbedBuilder()
                .setColor('#1DB954')
                .setTitle('🎵 Kişisel Çalma Listelerin Efendisi')
                .setDescription(list)
                .setFooter({ text: 'Elit Prestige • Senin Müziğin' });

            return await interaction.smartReply({ embeds: [embed] });
        }

        if (subcommand === 'delete') {
            db.deleteUserPlaylist(userId, name);
            return await interaction.smartReply({ content: `✅ **${name}** isim deki liste silindi.` });
        }
    },
};

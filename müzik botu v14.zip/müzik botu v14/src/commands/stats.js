const { SlashCommandBuilder } = require('discord.js');
const { generateStatsCard } = require('../utils/canvasBuilder');
const os = require('os');
const db = require('../database/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Botun sistem istatistiklerini gösterir'),

    async execute(interaction, client) {
        const uptimeRaw = process.uptime();
        const d = Math.floor(uptimeRaw / 86400);
        const h = Math.floor((uptimeRaw % 86400) / 3600);
        const m = Math.floor((uptimeRaw % 3600) / 60);

        const mem = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
        const ping = client.ws.ping;

        const guilds = client.guilds.cache.size;
        let users = 0;
        client.guilds.cache.forEach(g => { if (g.available) users += g.memberCount || 0; });

        const players = client.lavalink?.players;
        const activePlayers = players ? [...players.values()].filter(p => p.playing).length : 0;

        const totalSongs = db.getGuild(interaction.guild.id).stats?.totalSongs || 0;

        const connectedNodes = client.lavalink.nodeManager.nodes.filter(n => n.connected).size;
        const totalNodes = client.lavalink.nodeManager.nodes.size;

        const health = Math.max(0, 100 - (ping / 15) - (parseFloat(mem) / 40)).toFixed(1);

        const statsData = {
            guilds,
            users: users > 0 ? users - 1 : 0,
            activePlayers,
            health: `${health}%`,
            totalPlayed: `${totalSongs} şarkı`,
            uptime: d > 0 ? `${d}g ${h}s ${m}d` : `${h}s ${m}d`,
            memory: mem,
            cpu: `${os.cpus()[0]?.model?.split(' ')[0] || '?'} (${os.cpus().length} çekirdek)`,
            platform: os.platform() === 'win32' ? 'Windows' : 'Linux',
            ping: `${ping} ms`,
            nodeStatus: `${connectedNodes}/${totalNodes} aktif`,
        };

        try {
            const attachment = await generateStatsCard(client, statsData);
            return interaction.smartReply({ files: [attachment] });
        } catch (e) {
            console.error('[Stats] Canvas hatası:', e?.message);
            // Fallback: text versiyonu
            return interaction.smartReply({
                content: [
                    `📊 **Sistem İstatistikleri**`,
                    `> **Sunucu:** ${guilds}  |  **Kullanıcı:** ${statsData.users}`,
                    `> **Aktif Çalar:** ${activePlayers}  |  **Toplam Çalınan:** ${totalSongs}`,
                    `> **Gecikme:** ${ping} ms  |  **Bellek:** ${mem} MB`,
                    `> **Çalışma Süresi:** ${statsData.uptime}`,
                    `> **Node:** ${statsData.nodeStatus}`,
                ].join('\n'),
                flags: 64
            });
        }
    },
};

const { SlashCommandBuilder } = require('discord.js');

const parseTime = (input) => {
    if (!input) return null;
    input = input.trim();

    // mm:ss veya h:mm:ss formatı
    if (input.includes(':')) {
        const parts = input.split(':').map(Number);
        if (parts.some(isNaN)) return null;
        if (parts.length === 2) return (parts[0] * 60 + parts[1]) * 1000;
        if (parts.length === 3) return (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000;
        return null;
    }

    // "90s" veya "90" (saniye olarak)
    const seconds = parseInt(input.replace(/[^0-9]/g, ''));
    if (isNaN(seconds)) return null;
    return seconds * 1000;
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('seek')
        .setDescription('Şarkıyı belirli bir zamana sarar')
        .addStringOption(opt =>
            opt.setName('sure')
                .setDescription('Sarmak istediğin süre — ör: 1:30, 2:05:10, 90s')
                .setRequired(true)
        ),

    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);

        if (!player || !player.queue.current) {
            return interaction.smartReply({ content: '⚠️ Şu an bir şarkı çalmıyor.', flags: 64 });
        }
        if (interaction.member.voice.channelId !== player.voiceChannelId) {
            return interaction.smartReply({ content: '❌ Bot ile aynı ses kanalında olmalısın!', flags: 64 });
        }
        if (player.queue.current.info.isStream) {
            return interaction.smartReply({ content: '❌ Canlı yayınlarda sarma yapılamaz.', flags: 64 });
        }

        const input = interaction.options.getString('sure');
        const seekMs = parseTime(input);

        if (seekMs === null || isNaN(seekMs)) {
            return interaction.smartReply({ content: '❌ Geçersiz format! Örnekler: `1:30`, `90s`, `2:05:10`', flags: 64 });
        }
        if (seekMs < 0 || seekMs > player.queue.current.info.length) {
            return interaction.smartReply({ content: `❌ Süre 0 ile ${formatDur(player.queue.current.info.length)} arasında olmalı.`, flags: 64 });
        }

        await player.seek(seekMs);
        return interaction.smartReply({ content: `⏩ **${formatDur(seekMs)}** konumuna sarıldı.` });
    },
};

function formatDur(ms) {
    const s = Math.floor((ms / 1000) % 60);
    const m = Math.floor((ms / 60000) % 60);
    const h = Math.floor(ms / 3600000);
    if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    return `${m}:${String(s).padStart(2,'0')}`;
}

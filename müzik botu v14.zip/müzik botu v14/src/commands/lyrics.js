const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Client } = require('genius-lyrics');
const genius = new Client(); // API Key opsiyonel, boş bırakıldığında public erişim kullanılır.

module.exports = {
    data: new SlashCommandBuilder()
        .setName('lyrics')
        .setDescription('Şarkı sözlerini profesyonel Genius motoruyla bulur.')
        .addStringOption(option =>
            option.setName('sarki')
                .setDescription('Şarkı ismi (Boş bırakılırsa çalan şarkı aranır)')
                .setRequired(false)),
    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);
        const manualQuery = interaction.options.getString('sarki');

        // --- 🛡️ HASSAS ARAMA MOTORU (Precision Search) ---
        // Eğer kullanıcı isim vermediyse, çalann şarkının sanatçısı ve adını birleştirerek "Gerçek" şarkıyı ara.
        let query = manualQuery;
        if (!query && player?.queue?.current) {
            const track = player.queue.current.info;
            query = `${track.author} - ${track.title}`;
        }

        if (!query) {
            return await interaction.smartReply({ content: '⚠️ Lütfen bir şarkı ismi belirtin veya önce müzik başlatın.' });
        }

        // --- 🧹 GELİŞMİŞ TEMİZLİK (YouTube & Metadata Stripper) ---
        const cleanQuery = (str) => {
            return str
                .replace(/\(Official Video\)/gi, '')
                .replace(/\(Official Audio\)/gi, '')
                .replace(/\(Music Video\)/gi, '')
                .replace(/\(Video\)/gi, '')
                .replace(/\(Lyrics\)/gi, '')
                .replace(/\(Official Lyric Video\)/gi, '')
                .replace(/\[Lyric Video\]/gi, '')
                .replace(/\[HD\]/gi, '')
                .replace(/\[Official\]/gi, '')
                .replace(/ft\..*/gi, '')
                .replace(/feat\..*/gi, '')
                .replace(/Produced by.*/gi, '')
                .replace(/Prod\..*/gi, '')
                .replace(/  +/g, ' ')
                .trim();
        };

        const finalQuery = cleanQuery(query);

        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply().catch(() => { });
        }

        try {
            const searches = await genius.songs.search(finalQuery);
            if (!searches || searches.length === 0) {
                return await interaction.editReply({ content: `❌ **"${finalQuery}"** için gerçek şarkı sözleri bulunamadı.` });
            }

            // --- 🎯 AKILLI EŞLEŞTİRME (Smart Matching) ---
            // Eğer otomatik aramaysa, çalınan sanatçıya en yakın olanı seç.
            let song = searches[0];
            if (!manualQuery && player?.queue?.current) {
                const artist = player.queue.current.info.author.toLowerCase();
                const matched = searches.find(s => s.artist.name.toLowerCase().includes(artist) || artist.includes(s.artist.name.toLowerCase()));
                if (matched) song = matched;
            }

            const lyrics = await song.lyrics() || "Sözler çekilemedi.";

            const lyricsEmbed = new EmbedBuilder()
                .setColor('#1DB954')
                .setAuthor({ name: 'Genius Verified Lyrics', iconURL: 'https://images.genius.com/f909db76b0577742a0004f217730e716.300x300x1.png' })
                .setTitle(`📜 ${song.fullTitle}`)
                .setURL(song.url)
                .setThumbnail(song.thumbnail)
                .setDescription(lyrics.length > 4050 ? lyrics.substring(0, 4050) + '...' : lyrics)
                .setFooter({ text: 'Elit Precision Lyrics • Piyasaya değil, gerçeğe imza atıyoruz.', iconURL: client.user.displayAvatarURL() })
                .setTimestamp();

            return await interaction.editReply({ embeds: [lyricsEmbed] });
        } catch (e) {
            console.error("Lyrics Error:", e);
            return await interaction.editReply({ content: '❌ Şarkı sözleri aranırken veya şarkı doğrulanırken bir hata oluştu.' });
        }
    },
};

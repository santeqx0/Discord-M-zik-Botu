const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../database/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Bot ayarlarını yapılandırır.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(sub =>
            sub.setName('dj')
                .setDescription('DJ rolünü ayarlar.')
                .addRoleOption(opt => opt.setName('rol').setDescription('DJ rolü').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('247')
                .setDescription('24/7 modunu açar veya kapatır.')
                .addBooleanOption(opt => opt.setName('aktif').setDescription('Aktif mi?').setRequired(true))
        ),
    async execute(interaction, client) {
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (subcommand === 'dj') {
            const role = interaction.options.getRole('rol');
            db.updateGuild(guildId, { djRole: role.id });

            const embed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('💎 Setup: DJ Sistemi')
                .setDescription(`✅ DJ rolü başarıyla ayarlandı: ${role}\n\n*Artık bu role sahip olanlar tüm müzik komutlarını yönetebilir.*`)
                .setFooter({ text: 'Elit Prestige • Kontrol Sende' });

            return await interaction.smartReply({ embeds: [embed] });
        }

        if (subcommand === '247') {
            const status = interaction.options.getBoolean('aktif');
            db.updateGuild(guildId, { stay247: status });

            const embed = new EmbedBuilder()
                .setColor(status ? '#2ECC71' : '#E74C3C')
                .setTitle('💎 Setup: 24/7 Modu')
                .setDescription(`✅ 24/7 modu **${status ? 'AKTİF' : 'DEVRE DIŞI'}** olarak ayarlandı.\n\n*${status ? 'Bot artık kanaldan hiç çıkmayacak.' : 'Kanal boşaldığında bot otomatik çıkacak.'}*`)
                .setFooter({ text: 'Elit Prestige • Kesintisiz Müzik' });

            return await interaction.smartReply({ embeds: [embed] });
        }
    },
};

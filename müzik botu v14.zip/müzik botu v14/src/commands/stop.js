const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stop')
        .setDescription('Müziği durdurur ve botu kanaldan çıkarır'),

    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);

        if (!player) {
            return interaction.smartReply({ content: '⚠️ Şu an aktif bir oturum yok.', flags: 64 });
        }
        if (interaction.member.voice.channelId !== player.voiceChannelId) {
            return interaction.smartReply({ content: '❌ Bot ile aynı ses kanalında olmalısın!', flags: 64 });
        }

        const { isDJ } = require('../utils/djCheck');
        if (!isDJ(interaction, player)) {
            return interaction.smartReply({ content: '❌ DJ yetkisi veya şarkıyı isteyen kişi olman gerekiyor!', flags: 64 });
        }

        // Eski now-playing kartını sil
        if (player.nowPlayingMessageId) {
            const ch = client.channels.cache.get(player.textChannelId);
            if (ch) {
                const msg = await ch.messages.fetch(player.nowPlayingMessageId).catch(() => null);
                if (msg) await msg.delete().catch(() => {});
            }
        }

        await player.destroy();
        return interaction.smartReply({ content: '🛑 Müzik durduruldu ve kanaldan ayrıldım.' });
    },
};

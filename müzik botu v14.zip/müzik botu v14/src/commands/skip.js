const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('skip')
        .setDescription('Çalan şarkıyı atlar')
        .addIntegerOption(opt =>
            opt.setName('adet')
                .setDescription('Kaç şarkı atlanacak? (varsayılan: 1)')
                .setMinValue(1)
                .setMaxValue(20)
                .setRequired(false)
        ),

    async execute(interaction, client) {
        const player = client.lavalink.getPlayer(interaction.guild.id);

        if (!player || !player.queue.current) {
            return interaction.smartReply({ content: '⚠️ Şu an bir şarkı çalmıyor.', flags: 64 });
        }
        if (interaction.member.voice.channelId !== player.voiceChannelId) {
            return interaction.smartReply({ content: '❌ Bot ile aynı ses kanalında olmalısın!', flags: 64 });
        }

        const { isDJ } = require('../utils/djCheck');
        if (!isDJ(interaction, player)) {
            return interaction.smartReply({ content: '❌ DJ yetkisi veya şarkıyı isteyen kişi olman gerekiyor!', flags: 64 });
        }

        const count = interaction.options.getInteger('adet') || 1;
        const skipped = player.queue.current?.info?.title || 'Bilinmiyor';

        // Birden fazla atla
        if (count > 1) {
            const toRemove = Math.min(count - 1, player.queue.tracks.length);
            if (toRemove > 0) player.queue.tracks.splice(0, toRemove);
        }

        await player.skip();

        if (count === 1) {
            return interaction.smartReply({ content: `⏭️ **"${skipped}"** atlandı.` });
        } else {
            return interaction.smartReply({ content: `⏭️ **${count} şarkı** atlandı.` });
        }
    },
};

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'db.json');

class Database {
    constructor() {
        if (!fs.existsSync(DB_PATH)) {
            fs.writeFileSync(DB_PATH, JSON.stringify({ guilds: {} }, null, 4));
        }
        this.data = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    }

    getGuild(guildId) {
        if (!this.data.guilds[guildId]) {
            this.data.guilds[guildId] = {
                djRole: null,
                stay247: false,
                playlists: {},
                stats: {
                    totalSongs: 0,
                    totalTime: 0
                }
            };
            this.save();
        }
        return this.data.guilds[guildId];
    }

    addSongToStats(guildId) {
        const guild = this.getGuild(guildId);
        if (!guild.stats) guild.stats = { totalSongs: 0, totalTime: 0 };
        guild.stats.totalSongs++;
        this.save();
    }

    updateGuild(guildId, updates) {
        const guild = this.getGuild(guildId);
        Object.assign(guild, updates);
        this.save();
    }

    getUserPlaylist(userId, playlistName) {
        if (!this.data.users) this.data.users = {};
        if (!this.data.users[userId]) this.data.users[userId] = { playlists: {} };
        return this.data.users[userId].playlists[playlistName] || null;
    }

    saveUserPlaylist(userId, playlistName, tracks) {
        if (!this.data.users) this.data.users = {};
        if (!this.data.users[userId]) this.data.users[userId] = { playlists: {} };
        this.data.users[userId].playlists[playlistName] = tracks;
        this.save();
    }

    deleteUserPlaylist(userId, playlistName) {
        if (this.data.users?.[userId]?.playlists?.[playlistName]) {
            delete this.data.users[userId].playlists[playlistName];
            this.save();
        }
    }

    save() {
        fs.writeFileSync(DB_PATH, JSON.stringify(this.data, null, 4));
    }
}

module.exports = new Database();

const db = require('../database/db');

/**
 * Kullanıcının DJ yetkisi olup olmadığını kontrol eder.
 * @param {import('discord.js').Interaction} interaction 
 * @param {import('lavalink-client').Player} player 
 */
function isDJ(interaction, player) {
    // Yöneticiyse her zaman yetkili
    if (interaction.member.permissions.has('Administrator')) return true;

    const guildData = db.getGuild(interaction.guild.id);
    const djRoleId = guildData.djRole;

    // DJ rolü varsa ve kullanıcıda varsa yetkili
    if (djRoleId && interaction.member.roles.cache.has(djRoleId)) return true;

    // Şarkıyı isteyen kişiyse yetkili (isteğe bağlı, genelde istenir)
    if (player && player.queue.current && player.queue.current.requesterId === interaction.user.id) return true;

    // Kanaldaki tek kişiyse yetkili
    const voiceChannel = interaction.member.voice.channel;
    if (voiceChannel && voiceChannel.members.filter(m => !m.user.bot).size === 1) return true;

    return false;
}

module.exports = { isDJ };

const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createCanvas, loadImage } = require('@napi-rs/canvas');

// ──────────────────────────────────────────────
// YARDIMCI FONKSİYONLAR
// ──────────────────────────────────────────────
const fmtTime = (ms) => {
    if (!ms || ms <= 0) return '∞';
    const s = Math.floor((ms / 1000) % 60);
    const m = Math.floor(ms / 60000);
    return `${m}:${String(s).padStart(2, '0')}`;
};

const truncate = (str, max) => (str && str.length > max ? str.slice(0, max - 1) + '…' : str || '');

// Kaynak renk teması
const getTheme = (source) => {
    const s = (source || '').toLowerCase();
    if (s.includes('spotify'))    return { accent: '#1DB954', label: 'SPOTIFY',    grad1: '#0f2b1a', grad2: '#0a1f12' };
    if (s.includes('youtube'))    return { accent: '#FF4444', label: 'YOUTUBE',    grad1: '#2b0f0f', grad2: '#1f0a0a' };
    if (s.includes('soundcloud')) return { accent: '#FF6500', label: 'SOUNDCLOUD', grad1: '#2b1a0f', grad2: '#1f120a' };
    if (s.includes('deezer'))     return { accent: '#A238FF', label: 'DEEZER',     grad1: '#1e0f2b', grad2: '#160a1f' };
    return                               { accent: '#5865F2', label: 'MUZIK',      grad1: '#0f1128', grad2: '#0a0c1f' };
};

// Rounded rect path
const roundRect = (ctx, x, y, w, h, r) => {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
};

// ──────────────────────────────────────────────
// 🎵 MÜZİK KARTI — ULTRA PREMIUM
// ──────────────────────────────────────────────
async function generateMusicCard(player) {
    const track = player.queue.current;
    if (!track) return null;

    const W = 960, H = 270;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    const info = track.info;
    const position = player.position || 0;
    const duration = info.length || 0;
    const progress = duration > 0 ? Math.min(1, position / duration) : 0;
    const theme = getTheme(info.sourceName);

    // ── Kapak resmi yükleme ──
    let art = null;
    const artCandidates = [
        info.artworkUrl,
        info.thumbnail,
        info.identifier ? `https://img.youtube.com/vi/${info.identifier}/maxresdefault.jpg` : null,
        info.identifier ? `https://img.youtube.com/vi/${info.identifier}/hqdefault.jpg` : null,
        'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=800&q=80'
    ].filter(Boolean);

    for (const url of artCandidates) {
        try { art = await loadImage(url); break; } catch {}
    }

    // ── 1. Arkaplan: Koyu gradient + kapak rengi yansıması ──
    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, theme.grad1);
    bgGrad.addColorStop(1, '#0d0d14');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    const glowGrad = ctx.createRadialGradient(W * 0.75, H * 0.5, 0, W * 0.75, H * 0.5, 400);
    glowGrad.addColorStop(0, theme.accent + '22');
    glowGrad.addColorStop(0.5, theme.accent + '08');
    glowGrad.addColorStop(1, 'transparent');
    ctx.fillStyle = glowGrad;
    ctx.fillRect(0, 0, W, H);

    // Sol kapak tarafı glow
    const leftGlow = ctx.createRadialGradient(140, H / 2, 0, 140, H / 2, 220);
    leftGlow.addColorStop(0, theme.accent + '15');
    leftGlow.addColorStop(1, 'transparent');
    ctx.fillStyle = leftGlow;
    ctx.fillRect(0, 0, W, H);

    // Üst ince çizgi (accent)
    const topLine = ctx.createLinearGradient(0, 0, W, 0);
    topLine.addColorStop(0, 'transparent');
    topLine.addColorStop(0.3, theme.accent + 'aa');
    topLine.addColorStop(0.7, theme.accent + 'aa');
    topLine.addColorStop(1, 'transparent');
    ctx.fillStyle = topLine;
    ctx.fillRect(0, 0, W, 2);

    // ── 2. Kapak resmi (kare, yuvarlak köşe) ──
    const PAD = 28;
    const COVER_S = H - PAD * 2; // 214px
    const COVER_X = PAD;
    const COVER_Y = PAD;

    // Gölge
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.9)';
    ctx.shadowBlur = 40;
    ctx.shadowOffsetX = 8;
    ctx.shadowOffsetY = 12;
    ctx.fillStyle = '#000';
    roundRect(ctx, COVER_X, COVER_Y, COVER_S, COVER_S, 16);
    ctx.fill();
    ctx.restore();

    // Kapak clip + çiz
    ctx.save();
    roundRect(ctx, COVER_X, COVER_Y, COVER_S, COVER_S, 16);
    ctx.clip();
    if (art) {
        const scale = Math.max(COVER_S / art.width, COVER_S / art.height);
        const dx = COVER_X + (COVER_S - art.width * scale) / 2;
        const dy = COVER_Y + (COVER_S - art.height * scale) / 2;
        ctx.drawImage(art, dx, dy, art.width * scale, art.height * scale);
    } else {
        const fallback = ctx.createLinearGradient(COVER_X, COVER_Y, COVER_X + COVER_S, COVER_Y + COVER_S);
        fallback.addColorStop(0, '#1a1a2e');
        fallback.addColorStop(1, '#16213e');
        ctx.fillStyle = fallback;
        ctx.fillRect(COVER_X, COVER_Y, COVER_S, COVER_S);
        ctx.fillStyle = 'rgba(255,255,255,0.15)';
        ctx.font = 'bold 90px serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('♪', COVER_X + COVER_S / 2, COVER_Y + COVER_S / 2);
    }
    ctx.restore();

    // Kapak üstüne parlama (glossy overlay)
    ctx.save();
    roundRect(ctx, COVER_X, COVER_Y, COVER_S, COVER_S, 16);
    ctx.clip();
    const glossGrad = ctx.createLinearGradient(COVER_X, COVER_Y, COVER_X, COVER_Y + COVER_S * 0.5);
    glossGrad.addColorStop(0, 'rgba(255,255,255,0.08)');
    glossGrad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = glossGrad;
    ctx.fillRect(COVER_X, COVER_Y, COVER_S, COVER_S);
    ctx.restore();

    // Çerçeve
    ctx.save();
    roundRect(ctx, COVER_X, COVER_Y, COVER_S, COVER_S, 16);
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();

    // ── 3. Metin Alanı ──
    const TX = COVER_X + COVER_S + 36;
    const TW = W - TX - PAD;
    const FONT = 'bold %SIZE%px Arial';

    // Platform badge
    const BADGE_W = Math.min(theme.label.length * 9 + 28, 130);
    const BADGE_H = 28;
    const BADGE_X = TX;
    const BADGE_Y = PAD - 2;

    // Badge arka plan
    ctx.save();
    ctx.fillStyle = theme.accent + '28';
    roundRect(ctx, BADGE_X, BADGE_Y, BADGE_W, BADGE_H, 6);
    ctx.fill();
    ctx.strokeStyle = theme.accent + '60';
    ctx.lineWidth = 1;
    roundRect(ctx, BADGE_X, BADGE_Y, BADGE_W, BADGE_H, 6);
    ctx.stroke();
    ctx.restore();

    // Badge yazı
    ctx.save();
    ctx.fillStyle = theme.accent;
    ctx.font = FONT.replace('%SIZE%', '11');
    ctx.letterSpacing = '1.5px';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(theme.label, BADGE_X + BADGE_W / 2, BADGE_Y + BADGE_H / 2 + 1);
    ctx.restore();

    // Şarkı adı
    ctx.save();
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    const titleRaw = truncate(info.title || 'Bilinmeyen', 38);
    const titleSize = titleRaw.length > 26 ? 28 : 34;
    ctx.font = FONT.replace('%SIZE%', titleSize);
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = 'rgba(0,0,0,0.6)';
    ctx.shadowBlur = 8;
    ctx.fillText(titleRaw, TX, BADGE_Y + BADGE_H + 38);
    ctx.restore();

    // Sanatçı adı
    ctx.save();
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.font = FONT.replace('%SIZE%', '18');
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ctx.fillText(truncate(info.author || 'Bilinmeyen Sanatçı', 42), TX, BADGE_Y + BADGE_H + 38 + titleSize + 8);
    ctx.restore();

    // ── 4. Progress Bar ──
    const BAR_Y = H - 82;
    const BAR_H = 5;
    const BAR_R = 3;
    const filledW = Math.max(0, Math.round(TW * progress));

    // Bar track
    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    roundRect(ctx, TX, BAR_Y, TW, BAR_H, BAR_R);
    ctx.fill();
    ctx.restore();

    // Dolu kısım
    if (filledW > 2) {
        ctx.save();
        ctx.shadowColor = theme.accent;
        ctx.shadowBlur = 8;
        const barGrad = ctx.createLinearGradient(TX, 0, TX + filledW, 0);
        barGrad.addColorStop(0, theme.accent + 'cc');
        barGrad.addColorStop(1, theme.accent);
        ctx.fillStyle = barGrad;
        roundRect(ctx, TX, BAR_Y, filledW, BAR_H, BAR_R);
        ctx.fill();
        ctx.restore();

        // Uç noktası
        ctx.save();
        ctx.fillStyle = '#FFFFFF';
        ctx.shadowColor = theme.accent;
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(TX + filledW, BAR_Y + BAR_H / 2, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }

    // Süre yazıları
    ctx.save();
    ctx.textBaseline = 'alphabetic';
    ctx.font = FONT.replace('%SIZE%', '13');
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.textAlign = 'left';
    ctx.fillText(fmtTime(position), TX, BAR_Y + BAR_H + 22);
    ctx.textAlign = 'right';
    ctx.fillText(fmtTime(duration), TX + TW, BAR_Y + BAR_H + 22);
    ctx.restore();

    // ── 5. Alt Bilgi ──
    const FOOTER_Y = H - 20;
    const volPct = Math.min(100, Math.max(0, player.volume || 0));
    const VOL_BAR_W = 80;
    const VOL_BAR_H = 4;
    const VOL_X = TX;
    const VOL_Y = FOOTER_Y - VOL_BAR_H - 1;

    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    ctx.font = FONT.replace('%SIZE%', '13');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${volPct}%`, VOL_X, VOL_Y + VOL_BAR_H / 2 + 1);
    ctx.restore();

    ctx.save();
    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    roundRect(ctx, VOL_X + 38, VOL_Y, VOL_BAR_W, VOL_BAR_H, 2);
    ctx.fill();
    const volFilled = Math.round(VOL_BAR_W * (volPct / 100));
    if (volFilled > 0) {
        ctx.fillStyle = theme.accent + 'bb';
        roundRect(ctx, VOL_X + 38, VOL_Y, volFilled, VOL_BAR_H, 2);
        ctx.fill();
    }
    ctx.restore();

    const loopMap = { track: 'DONOGU: SARKI', queue: 'DONOGU: SIRA' };
    const loopTxt = loopMap[player.repeatMode];
    if (loopTxt) {
        ctx.save();
        ctx.fillStyle = theme.accent + 'cc';
        ctx.font = FONT.replace('%SIZE%', '11');
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(loopTxt, VOL_X + 38 + VOL_BAR_W + 14, VOL_Y + VOL_BAR_H / 2);
        ctx.restore();
    }

    const req = track.requester || info.requester;
    const reqName = req?.username || req?.globalName || req?.tag || '';
    if (reqName) {
        ctx.save();
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = 'rgba(255,255,255,0.35)';
        ctx.font = 'italic ' + FONT.replace('bold ', '').replace('%SIZE%', '12');
        ctx.fillText(`Isteyen: @${reqName}`, TX + TW, VOL_Y + VOL_BAR_H / 2);
        ctx.restore();
    }

    ctx.save();
    ctx.globalAlpha = 0.04;
    for (let i = 0; i < 5; i++) {
        const lx = W - 80 + i * 12;
        ctx.strokeStyle = theme.accent;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(lx, 0);
        ctx.lineTo(lx, H);
        ctx.stroke();
    }
    ctx.restore();

    return new AttachmentBuilder(await canvas.encode('png'), { name: 'elit-music.png' });
}

// ──────────────────────────────────────────────
// 🎮 KONTROL BUTONLARI
// ──────────────────────────────────────────────
function createControlButtons(player) {
    const isPaused = player.paused;
    const loop = player.repeatMode || 'off';

    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('music_previous')
            .setEmoji('⏮️')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('music_resume_pause')
            .setEmoji(isPaused ? '▶️' : '⏸️')
            .setStyle(isPaused ? ButtonStyle.Success : ButtonStyle.Primary),
        new ButtonBuilder()
            .setCustomId('music_skip')
            .setEmoji('⏭️')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('music_shuffle')
            .setEmoji('🔀')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('music_loop')
            .setEmoji(loop === 'track' ? '🔂' : loop === 'queue' ? '🔁' : '➡️')
            .setStyle(loop !== 'off' ? ButtonStyle.Success : ButtonStyle.Secondary),
    );

    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('music_vol_down')
            .setEmoji('🔉')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('music_vol_up')
            .setEmoji('🔊')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('music_modal_volume')
            .setEmoji('🎚️')
            .setLabel('Ses')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('music_modal_search')
            .setEmoji('🔎')
            .setLabel('Ekle')
            .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
            .setCustomId('music_stop')
            .setEmoji('🛑')
            .setLabel('Kapat')
            .setStyle(ButtonStyle.Danger),
    );

    const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('music_queue')
            .setEmoji('📋')
            .setLabel('Sıra')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('music_clear')
            .setEmoji('🗑️')
            .setLabel('Sırayı Temizle')
            .setStyle(ButtonStyle.Danger),
    );

    return [row1, row2, row3];
}

// ──────────────────────────────────────────────
// 📊 İSTATİSTİK KARTI
// ──────────────────────────────────────────────
async function generateStatsCard(client, stats) {
    const W = 860, H = 420;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');
    const FONT = 'bold %SIZE%px Arial';

    ctx.fillStyle = '#080810';
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = 'rgba(255,255,255,0.025)';
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 40) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
    for (let y = 0; y < H; y += 40) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }

    const glow = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, 400);
    glow.addColorStop(0, 'rgba(88,101,242,0.12)');
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);

    let avatar;
    try { avatar = await loadImage(client.user.displayAvatarURL({ extension: 'png', size: 256 })); } catch { }

    if (avatar) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(90, 90, 58, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(avatar, 32, 32, 116, 116);
        ctx.restore();

        ctx.strokeStyle = '#5865F2';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(90, 90, 59, 0, Math.PI * 2);
        ctx.stroke();
    }

    ctx.fillStyle = '#FFFFFF';
    ctx.font = FONT.replace('%SIZE%', '32');
    ctx.textAlign = 'left';
    ctx.fillText(client.user.username, 170, 72);
    ctx.fillStyle = '#5865F2';
    ctx.font = FONT.replace('%SIZE%', '16');
    ctx.fillText('Muzik Botu - Sistem Raporu', 172, 100);

    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(28, 140); ctx.lineTo(W - 28, 140); ctx.stroke();

    const cards = [
        { label: 'SUNUCU',       value: stats.guilds,         color: '#5865F2' },
        { label: 'KULLANICI',    value: stats.users,          color: '#57F287' },
        { label: 'AKTIF CALAR',  value: stats.activePlayers,  color: '#FEE75C' },
        { label: 'GECIKME',      value: stats.ping,           color: '#57F287' },
        { label: 'BELLEK',       value: `${stats.memory} MB`, color: '#EB459E' },
        { label: 'CALISMA',      value: stats.uptime,         color: '#5865F2' },
    ];

    const cardW = 240, cardH = 80, gap = 20;
    const startX = 28, startY = 160;

    cards.forEach((c, i) => {
        const col = i % 3;
        const row = Math.floor(i / 3);
        const x = startX + col * (cardW + gap);
        const y = startY + row * (cardH + gap);

        ctx.fillStyle = 'rgba(255,255,255,0.03)';
        roundRect(ctx, x, y, cardW, cardH, 12);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.06)';
        ctx.lineWidth = 1;
        roundRect(ctx, x, y, cardW, cardH, 12);
        ctx.stroke();

        ctx.fillStyle = c.color;
        roundRect(ctx, x, y + 12, 3, cardH - 24, 2);
        ctx.fill();

        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.font = FONT.replace('%SIZE%', '11');
        ctx.textAlign = 'left';
        ctx.fillText(c.label, x + 18, y + 28);

        ctx.fillStyle = '#FFFFFF';
        ctx.font = FONT.replace('%SIZE%', String(c.value).length > 10 ? '16' : '20');
        ctx.fillText(String(c.value).slice(0, 20), x + 18, y + 58);
    });

    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    ctx.font = FONT.replace('%SIZE%', '12');
    ctx.textAlign = 'center';
    ctx.fillText(
        `Platform: ${stats.platform}  |  Toplam Calınan: ${stats.totalPlayed}`,
        W / 2, H - 18
    );

    return new AttachmentBuilder(await canvas.encode('png'), { name: 'stats.png' });
}

module.exports = { generateMusicCard, generateStatsCard, createControlButtons };

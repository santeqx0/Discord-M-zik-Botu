@echo off
title ELIT PRESTIGE - SARSILMAZ KURULUM
color 0a
cls
echo.
echo  ##########################################################
echo  #                                                        #
echo  #          ELIT PRESTIGE - KURULUM TERMINALI             #
echo  #         ------------------------------------          #
echo  #        MODUL: SARSILMAZ ALTYAPI YUKLEYICI V12         #
echo  #                                                        #
echo  ##########################################################
echo.
echo  [SYSTEM] Sartlar kontrol ediliyor...
echo  [SYSTEM] Moduller indiriliyor, bu islem internet hiziniza baglidir.
echo.
npm install
echo.
echo  ##########################################################
echo  #                                                        #
echo  #         KURULUM BASARIYLA TAMAMLANDI!                  #
echo  #      Simdi 'KOMUTLARI-MUHURLE.bat'i calistirin.        #
echo  #                                                        #
echo  ##########################################################
echo.
pause

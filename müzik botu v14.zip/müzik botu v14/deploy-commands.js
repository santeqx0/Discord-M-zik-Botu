require('dotenv').config();
const fs = require('fs');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');

const commands = [];
const commandFiles = fs.readdirSync('./src/commands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(`./src/commands/${file}`);
    commands.push(command.data.toJSON());
}

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

(async () => {
    try {
        console.log(' [SYSTEM] Slash (/) komutları taranıyor ve mühürleniyor...');

        await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commands },
        );

        console.log(' [SUCCESS] Tüm komutlar Sarsılmaz (/) modunda Discord\'a mühürlendi. (Elit Prestige)');
    } catch (error) {
        console.error(' [CRITICAL ERROR] Komutlar mühürlenirken merkezi bir hata saptandı:', error);
    }
})();

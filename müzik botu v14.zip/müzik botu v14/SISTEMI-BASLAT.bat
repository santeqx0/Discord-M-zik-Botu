@echo off
title ELIT PRESTIGE - SARSILMAZ BASLATICI
color 0b
cls
echo.
echo  ##########################################################
echo  #                                                        #
echo  #          ELIT PRESTIGE - SISTEM MERKEZI                #
echo  #         ------------------------------------          #
echo  #        MODUL: SARSILMAZ MOTOR V12.5 (ACTIVE)          #
echo  #                                                        #
echo  ##########################################################
echo.
echo  [SYSTEM] Cekirdek baglantisi kuruluyor...
echo  [SYSTEM] Slash (/) komutlari otomatik muhurleniyor...
echo.
node deploy-commands.js
echo.
echo  [SYSTEM] Papaz-Lock guvenlik zirhi aktif.
echo  [SYSTEM] Bot yukleniyor...
echo.
node index.js
echo.
echo  [WARNING] Sistem beklenmedik bir sekilde durdu.
pause
